from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters
from instagrapi import Client
import yt_dlp
import os
from config import TELEGRAM_BOT_TOKEN, INSTAGRAM_USERNAME, INSTAGRAM_PASSWORD

cl = Client()
cl.login(INSTAGRAM_USERNAME, INSTAGRAM_PASSWORD)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Kirim link TikTok/Instagram buat gue upload ke IG Reels lo.")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    url = update.message.text
    if "tiktok.com" in url or "instagram.com" in url:
        await update.message.reply_text("Sedang download videonya bro...")

        ydl_opts = {
            'outtmpl': 'video.%(ext)s',
            'format': 'mp4',
            'quiet': True
        }
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])

        video_path = next((f for f in os.listdir() if f.startswith("video.") and f.endswith(".mp4")), None)
        if video_path:
            await update.message.reply_text("Upload ke Instagram Reels...")
            cl.clip_upload(video_path, caption="Auto-upload via bot 🤖")
            os.remove(video_path)
            await update.message.reply_text("✅ Berhasil diupload ke IG Reels!")
        else:
            await update.message.reply_text("❌ Gagal download video, coba lagi.")

app = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

app.run_polling()